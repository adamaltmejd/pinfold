import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import signal
import subprocess
import sys
import time
import secrets
import urllib.request

import runtime as r

RESULT = {'checks': {}, 'scope': 'x86_64 nested KVM; fixed-input fixture; synthetic secrets only'}
guardian = None
owner = None
logs = []

def check(name, condition, detail=None, fatal=True):
    RESULT['checks'][name] = {'pass': bool(condition), 'detail': detail}
    print(name + ': ' + ('PASS' if condition else 'FAIL'), flush=True)
    if not condition and fatal: raise AssertionError(name)

def start(mode='normal'):
    global guardian
    guardian = subprocess.Popen([sys.executable, str(r.BASE/'runtime.py'), 'launch', mode], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
    selector = selectors.DefaultSelector(); selector.register(guardian.stdout, selectors.EVENT_READ)
    output = bytearray(); marker = ('trial-'+mode).encode() if mode in ['before-spawn','before-exec'] else b'trial-guest-ready'
    deadline = time.monotonic() + 40
    try:
        while marker not in output:
            left = deadline-time.monotonic()
            if left <= 0: raise RuntimeError('guest-readiness-timeout')
            if not selector.select(left): raise RuntimeError('guest-readiness-timeout')
            part = os.read(guardian.stdout.fileno(), 65536)
            if not part: raise RuntimeError('guest-start-failed')
            output.extend(part)
    finally:
        selector.close()
        path = r.BASE / ('boot-' + str(len(logs)) + '.log')
        path.write_bytes(output); logs.append(path)
    return r.current()

def kill_guardian():
    global guardian
    if guardian is not None:
        if guardian.poll() is None: guardian.kill()
        guardian.wait(timeout=10)

def teardown():
    global guardian
    before=r.current()
    kill_guardian()
    rec = r.stop(before['generation'] if before else None)
    if guardian is not None:
        tail = guardian.stdout.read()
        if logs:
            with logs[-1].open('ab') as f: f.write(tail)
        guardian.stdout.close(); guardian = None
    return rec

def admission():
    p = subprocess.run([sys.executable, str(r.BASE/'runtime.py'), 'admit'], capture_output=True, text=True, timeout=10)
    return p.returncode, p.stdout.strip()

def fields(pid):
    lines = Path('/proc/'+str(pid)+'/status').read_text().splitlines()
    names = ['Uid', 'Gid', 'Groups', 'CapInh', 'CapPrm', 'CapEff', 'CapBnd', 'CapAmb', 'NoNewPrivs', 'Seccomp', 'NSpid']
    return {k:v.strip() for line in lines if ':' in line for k,v in [line.split(':',1)] if k in names}

def command(argv, env=None):
    result = r.rpc({'argv': argv, 'env': env or {}})
    if result.get('code') != 0: raise RuntimeError('guest-command-failed: ' + json.dumps(result))
    return result['stdout']

def zero_caps(status):
    return all(int(status[k],16)==0 for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb'])

def parse_status(value):
    return {k:v.strip() for line in value.splitlines() if ':' in line for k,v in [line.split(':',1)]}

def scan(secret):
    needle = secret.encode(); matches=[]; count=0
    for path in r.BASE.rglob('*'):
        if not path.is_file() or path.is_symlink(): continue
        count+=1
        with path.open('rb') as f:
            tail=b''
            while chunk:=f.read(1024*1024):
                data=tail+chunk
                if needle in data: matches.append(str(path)); break
                tail=data[-len(needle):]
    # No secret-bearing process environment is inspected or printed; the source caller
    # and authorized guest command necessarily possess the secret in memory.
    for path in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            if needle in path.read_bytes(): matches.append(str(path))
        except (FileNotFoundError, PermissionError, ProcessLookupError): pass
    return {'matches': matches, 'regular_files_scanned':count}

resource.setrlimit(resource.RLIMIT_CORE, (0,0))
secret = secrets.token_hex(32)
try:
    manifest = json.loads((r.BASE/'manifest.json').read_text())
    checksum = urllib.request.urlopen(manifest['firecracker_archive']['url']+'.sha256.txt', timeout=30).read().decode().split()[0]
    check('published_release_checksum', checksum == manifest['firecracker_archive']['sha256'])
    RESULT['manifest'] = manifest
    canary=secrets.token_hex(32)
    canary_path=r.BASE/'public-scanner-canary'
    canary_path.write_bytes(b'x'*(1024*1024-12)+canary.encode()+b'y')
    check('scanner_positive_control',str(canary_path) in scan(canary)['matches'])
    canary_path.unlink()
    check('scanner_removed_canary_absent',scan(canary)['matches']==[])
    check('trial_host_swap_disabled',len(Path('/proc/swaps').read_text().splitlines())==1)
    root_hash = hashlib.sha256((r.BASE/'root.ext4').read_bytes()).hexdigest()
    inode = r.VOLUME.stat().st_ino

    start('before-spawn'); kill_guardian()
    check('pre_spawn_owner_death_reclaimable', admission() == (0,'volume-available'))
    teardown()

    pre_exec=start('before-exec');kill_guardian()
    check('forked_child_covered_before_exec',r.populated(pre_exec) and admission()==(23,'volume-vmm-alive'))
    teardown()

    rec = start()
    pids = [int(v) for v in (r.CGROOT/rec['cgroup']/'cgroup.procs').read_text().split()]
    vmm = [p for p in pids if Path('/proc/'+str(p)+'/comm').read_text().strip()=='firecracker'][0]
    host = fields(vmm); guard = fields(guardian.pid)
    RESULT['host_vmm_status'] = host; RESULT['guardian_status'] = guard
    active_zero=all(int(host[k],16)==0 for k in ['CapInh','CapPrm','CapEff','CapAmb'])
    check('host_vmm_nonroot_no_active_capabilities', host['Uid'].split()==['60001']*4 and host['Gid'].split()==['60001']*4 and host['Groups']=='' and active_zero and host['NoNewPrivs']=='1' and host['Seccomp']=='2',host)
    check('stock_jailer_empty_bounding_set',int(host['CapBnd'],16)==0,{'observed':host['CapBnd'],'limitation':'stock jailer does not clear bounding capabilities'},fatal=False)
    check('guardian_privilege_drop', guard['Uid'].split()==['60002']*4 and guard['Gid'].split()==['60002']*4 and guard['Groups']=='' and zero_caps(guard) and guard['NoNewPrivs']=='1',guard)
    namespaces = {n: os.readlink('/proc/'+str(vmm)+'/ns/'+n) != os.readlink('/proc/self/ns/'+n) for n in ['mnt','pid','net']}
    check('vmm_namespaces_separate', all(namespaces.values()),namespaces)
    actual_root=os.stat('/proc/'+str(vmm)+'/root'); expected_root=os.stat(rec['jail'])
    check('jailer_chroot', (actual_root.st_dev,actual_root.st_ino)==(expected_root.st_dev,expected_root.st_ino),{'proc_root':os.readlink('/proc/'+str(vmm)+'/root'),'actual':[actual_root.st_dev,actual_root.st_ino],'expected':[expected_root.st_dev,expected_root.st_ino]})

    probe = json.loads(command(['/init','probe']))
    RESULT['guest_probe'] = probe
    for name,raw in [('guest_workload',probe['status']),('guest_pid1',probe['pid1_status'])]:
        s=parse_status(raw)
        check(name+'_privilege_drop',s['Uid'].split()==['1000']*4 and s['Gid'].split()==['1000']*4 and s['Groups']=='' and zero_caps(s) and s['NoNewPrivs']=='1' and s['Seccomp']=='2')
    check('guest_privileged_operations_denied',all(probe[k]=={'rc':-1,'errno':1} for k in ['setuid_root','userns','remount']))
    check('guest_readonly_root_and_raw_disk_denied',probe['root_write_errno']==30 and probe['raw_disk_errno']==13 and probe['host_control_errno']==2)
    check('guest_no_nic',probe['net']==['lo'])
    check('trial_guest_swap_disabled',len(command(['/bin/cat','/proc/swaps']).splitlines())==1)
    check('guest_volume_positive_write',command(['/bin/cat','/work/positive'])=='allowed')
    control=json.loads(command(['/init','local-control']))
    check('guest_control_rejects_local_peer',control.get('response')=='host-only\n',{'observed':control,'limitation':'a timeout does not establish peer rejection'},fatal=False)
    denied = subprocess.run([sys.executable,'-c','import socket,sys;s=socket.socket(socket.AF_UNIX);s.connect(sys.argv[1])',str(Path(rec['jail'])/'api.sock')],user=1000,group=1000,extra_groups=[],capture_output=True)
    check('unprivileged_host_api_path_denied',denied.returncode != 0 and b'PermissionError' in denied.stderr)

    sock=r.connection()
    owner=subprocess.Popen([sys.executable,str(r.BASE/'owner.py'),str(sock.fileno())],pass_fds=(sock.fileno(),),user=1000,group=1000,extra_groups=[],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    sock.close()
    owner.stdin.write(secret+'\n');owner.stdin.flush()
    delivery=json.loads(owner.stdout.readline())
    digest=json.loads(delivery['stdout'])
    check('secret_delivered_to_unprivileged_guest',delivery['code']==0 and digest['sha256']==hashlib.sha256(secret.encode()).hexdigest() and digest['length']==len(secret))
    check('secret_not_in_guest_argv',digest['cmdline_sha256']==hashlib.sha256(b'/init\x00secret\x00').hexdigest())
    check('caller_is_unprivileged',fields(owner.pid)['Uid'].split()==['1000']*4)
    check('caller_ready',owner.stdout.readline().strip()=='owner-ready')
    check('malformed_secret_input_redacted',r.rpc({'argv':{'bad':secret},'env':{}})=={'error':'invalid-request'} and r.rpc({'argv':['/init','secret'],'env':{'bad':[secret]}})=={'error':'invalid-request'})
    check('failed_exec_redacted',r.rpc({'argv':['/missing/'+secret],'env':{}})=={'error':'exec-failed'})
    check('volume_refuses_concurrent_attach',admission()==(23,'volume-vmm-alive'))
    try:
        r.stop('deliberately-stale-generation')
        stale_refused=False
    except RuntimeError as exc: stale_refused=str(exc)=='stale-generation'
    check('stale_cleanup_cannot_stop_live_generation',stale_refused and r.populated(rec))
    writer=r.rpc({'op':'writer'})
    check('active_writer_ready',writer['ready']=='writer-ready')
    counter_before=int(command(['/bin/cat','/work/counter']).strip())
    owner.kill();owner.wait(timeout=10)
    check('owner_death_does_not_release_volume',r.populated(rec) and admission()==(23,'volume-vmm-alive'))
    kill_guardian()
    check('guardian_death_does_not_release_volume',r.populated(rec) and admission()==(23,'volume-vmm-alive'))
    after_death=int(command(['/bin/cat','/work/counter']).strip())
    check('orphan_vmm_still_writing',int(command(['/bin/cat','/work/counter']).strip())>after_death)
    teardown()
    check('recovery_confirms_cgroup_empty',not (r.CGROOT/rec['cgroup']).exists())
    scan1=scan(secret);check('no_secret_in_persisted_files_or_host_argv',scan1['matches']==[],scan1)

    rec2=start()
    recovered=int(command(['/bin/cat','/work/counter']).strip())
    check('same_volume_recovers_after_vmm_sigkill',r.VOLUME.stat().st_ino==inode and recovered>=counter_before,{'before':counter_before,'recovered':recovered,'inode':inode})
    check('persisted_marker_survives',command(['/bin/cat','/work/positive'])=='allowed')
    check('recovered_volume_accepts_writes',json.loads(command(['/init','probe']))['raw_disk_errno']==13)
    check('no_stale_secret_in_next_exec',command(['/bin/sh','-c','test -z "$TRIAL_SECRET" && echo absent'])=='absent\n')
    # More requests expose zombie accumulation in PID 1 without timing-dependent sleeps.
    for _ in range(20): command(['/bin/sh','-c','true'])
    states=command(['/bin/sh','-c',"for p in /proc/[0-9]*/status; do /bin/busybox grep '^State:' \"$p\"; done"])
    check('guest_reaps_completed_requests','Z (zombie)' not in states)
    teardown()
    check('readonly_root_unchanged',hashlib.sha256((r.BASE/'root.ext4').read_bytes()).hexdigest()==root_hash)
    check('volume_available_after_confirmed_teardown',admission()==(0,'volume-available'))
    scan2=scan(secret);check('final_no_secret_persistence',scan2['matches']==[],scan2)
    RESULT['complete']=True
except BaseException as exc:
    RESULT['complete']=False;RESULT['failure_type']=type(exc).__name__;RESULT['failure']=str(exc)
    print('TRIAL FAILED: '+type(exc).__name__+': '+str(exc),flush=True)
finally:
    if owner is not None and owner.poll() is None: owner.kill();owner.wait(timeout=10)
    if owner is not None:
        owner_error=owner.stderr.read()
        RESULT['owner_stderr_redacted']=owner_error.replace(secret,'[redacted]')
    try: teardown()
    except BaseException as exc: RESULT['cleanup_error']=type(exc).__name__+': '+str(exc)
    RESULT['remaining_trial_cgroups']=[str(p) for p in r.CGROOT.glob('pinfold-trial-*')]
    (r.BASE/'results.json').write_text(json.dumps(RESULT,indent=2))
    print(json.dumps({'complete':RESULT.get('complete'),'checks':len(RESULT['checks']),'cleanup_error':RESULT.get('cleanup_error')}),flush=True)
    sys.exit(0 if RESULT.get('complete') and not RESULT.get('cleanup_error') else 1)
