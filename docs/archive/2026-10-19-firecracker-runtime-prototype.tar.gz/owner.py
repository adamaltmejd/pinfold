import json
import os
import resource
import socket
import sys

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
secret = sys.stdin.readline().rstrip('\n')
sock = socket.socket(fileno=int(sys.argv[1]))
sock.settimeout(20)
sock.sendall(json.dumps({'argv': ['/init', 'secret'], 'env': {'TRIAL_SECRET': secret}}).encode() + b'\n')
with sock.makefile('rb') as f:
    result = json.loads(f.readline())
print(json.dumps(result), flush=True)
sock.close()
print('owner-ready', flush=True)
sys.stdin.read()
