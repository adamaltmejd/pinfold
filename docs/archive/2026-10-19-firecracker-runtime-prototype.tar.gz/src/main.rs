use std::collections::BTreeMap;
use std::ffi::CString;
use std::fs::{self, File, OpenOptions};
use std::io::{BufRead, BufReader, Read, Seek, SeekFrom, Write};
use std::os::fd::{FromRawFd};
use std::process::{Command, Stdio};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};

fn checked(rc: i32, what: &str) {
    if rc < 0 { panic!("{what}: {}", std::io::Error::last_os_error()); }
}
fn c(s: &str) -> CString { CString::new(s).unwrap() }
fn mount(source: &str, target: &str, kind: &str, flags: libc::c_ulong, data: &str) {
    unsafe { checked(libc::mount(c(source).as_ptr(),c(target).as_ptr(),c(kind).as_ptr(),flags,c(data).as_ptr().cast()), "mount"); }
}
fn restriction() {
    // Prototype filter only: prohibit namespace creation/entry. Not the production allowlist.
    let stmt = |code, k| libc::sock_filter { code, jt: 0, jf: 0, k };
    let jump = |k, jt, jf| libc::sock_filter { code: 0x15, jt, jf, k };
    let mut f = vec![stmt(0x20,4),jump(0xc000003e,1,0),stmt(0x06,0x80000000),stmt(0x20,0),
        libc::sock_filter {code:0x35,jt:0,jf:1,k:0x40000000},stmt(0x06,0x50000|1),
        jump(libc::SYS_unshare as u32,0,1),stmt(0x06,0x50000|1),
        jump(libc::SYS_setns as u32,0,1),stmt(0x06,0x50000|1),
        jump(libc::SYS_clone3 as u32,0,1),stmt(0x06,0x50000|38),
        jump(libc::SYS_clone as u32,0,3),stmt(0x20,16),
        libc::sock_filter {code:0x45,jt:0,jf:1,k:libc::CLONE_NEWUSER as u32},stmt(0x06,0x50000|1),
        stmt(0x06,0x7fff0000)];
    let p = libc::sock_fprog {len:f.len() as u16,filter:f.as_mut_ptr()};
    unsafe {checked(libc::prctl(libc::PR_SET_SECCOMP,2,&p),"seccomp");}
}
fn status(path: &str) -> String { fs::read_to_string(path).unwrap_or_default() }
fn attempt(mut f: impl FnMut() -> i32) -> Value {
    let rc=f(); let err=if rc < 0 {std::io::Error::last_os_error().raw_os_error()} else {None};
    json!({"rc":rc,"errno":err})
}
fn probe() -> Value {
    let before=status("/proc/self/status");
    let root_write=fs::write("/must-not-exist",b"no").err().and_then(|e|e.raw_os_error());
    let raw_disk=OpenOptions::new().read(true).write(true).open("/dev/vdb").err().and_then(|e|e.raw_os_error());
    let host_control=File::open("/api.sock").err().and_then(|e|e.raw_os_error());
    let mut positive=File::create("/work/positive").unwrap(); positive.write_all(b"allowed").unwrap();positive.sync_all().unwrap();
    let setuid=attempt(|| unsafe{libc::setuid(0)});
    let userns=attempt(|| unsafe{libc::unshare(libc::CLONE_NEWUSER)});
    let remount=attempt(|| unsafe{libc::mount(std::ptr::null(),c("/").as_ptr(),std::ptr::null(),libc::MS_REMOUNT,std::ptr::null())});
    json!({"status":before,"pid1_status":status("/proc/1/status"),"setuid_root":setuid,"userns":userns,"remount":remount,"root_write_errno":root_write,"raw_disk_errno":raw_disk,"host_control_errno":host_control,"net":fs::read_dir("/sys/class/net").unwrap().map(|e|e.unwrap().file_name().to_string_lossy().to_string()).collect::<Vec<_>>()})
}
fn secret() {
    let value=std::env::var("TRIAL_SECRET").unwrap();
    // Output a one-way digest only. The plaintext is never written by the fixture.
    println!("{}",json!({"sha256":format!("{:x}",Sha256::digest(value.as_bytes())),"length":value.len(),"cmdline_sha256":format!("{:x}",Sha256::digest(fs::read("/proc/self/cmdline").unwrap()))}));
}
fn writer() {
    let mut f=OpenOptions::new().create(true).write(true).truncate(true).open("/work/counter").unwrap();
    let mut n=0u64;
    loop { n+=1; f.seek(SeekFrom::Start(0)).unwrap();write!(f,"{n:020}\n").unwrap();f.sync_all().unwrap();if n==1 {println!("writer-ready");std::io::stdout().flush().unwrap();} }
}
fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("probe")=>{println!("{}",probe());return},
        Some("secret")=>{secret();return},
        Some("writer")=>{writer();return},
        Some("local-control")=>{
            unsafe {
                let fd=libc::socket(libc::AF_VSOCK,libc::SOCK_STREAM,0);
                let mut a:libc::sockaddr_vm=std::mem::zeroed();a.svm_family=libc::AF_VSOCK as _;a.svm_cid=1;a.svm_port=7000;
                let rc=libc::connect(fd,(&a as *const libc::sockaddr_vm).cast(),std::mem::size_of_val(&a) as _);
                if rc<0 {println!("{}",json!({"connect_errno":std::io::Error::last_os_error().raw_os_error()}));}
                else {let mut f=File::from_raw_fd(fd);let mut buf=[0u8;64];let n=f.read(&mut buf).unwrap_or(0);println!("{}",json!({"response":String::from_utf8_lossy(&buf[..n])}));}
            } return
        },
        _=>{}
    }
    assert_eq!(std::process::id(),1);
    mount("proc","/proc","proc",libc::MS_NOSUID|libc::MS_NODEV|libc::MS_NOEXEC,"");
    mount("sysfs","/sys","sysfs",libc::MS_NOSUID|libc::MS_NODEV|libc::MS_NOEXEC,"");
    mount("devtmpfs","/dev","devtmpfs",libc::MS_REMOUNT|libc::MS_NOSUID,"");
    mount("tmpfs","/tmp","tmpfs",libc::MS_NOSUID|libc::MS_NODEV,"mode=1777,size=16m");
    mount("/dev/vdb","/work","ext4",libc::MS_NOSUID|libc::MS_NODEV,"");
    unsafe {
        let lim=libc::rlimit {rlim_cur:0,rlim_max:0};checked(libc::setrlimit(libc::RLIMIT_CORE,&lim),"core limit");
        checked(libc::chown(c("/work").as_ptr(),1000,1000),"chown work");
        for cap in 0..=40 {checked(libc::prctl(libc::PR_CAPBSET_DROP,cap,0,0,0),"cap drop");}
        checked(libc::setgroups(0,std::ptr::null()),"groups");
        checked(libc::setresgid(1000,1000,1000),"gid");checked(libc::setresuid(1000,1000,1000),"uid");
        checked(libc::prctl(libc::PR_SET_NO_NEW_PRIVS,1,0,0,0),"nnp");
        checked(libc::prctl(libc::PR_SET_DUMPABLE,0,0,0,0),"dumpable");
    }
    restriction();
    unsafe {
        let fd=libc::socket(libc::AF_VSOCK,libc::SOCK_STREAM|libc::SOCK_CLOEXEC,0);checked(fd,"vsock");
        let mut a:libc::sockaddr_vm=std::mem::zeroed();a.svm_family=libc::AF_VSOCK as _;a.svm_cid=u32::MAX;a.svm_port=7000;
        checked(libc::bind(fd,(&a as *const libc::sockaddr_vm).cast(),std::mem::size_of_val(&a) as _),"bind");checked(libc::listen(fd,8),"listen");
        libc::signal(libc::SIGCHLD,libc::SIG_IGN);
        println!("trial-guest-ready");
        loop {
            let mut peer:libc::sockaddr_vm=std::mem::zeroed();let mut len=std::mem::size_of_val(&peer) as libc::socklen_t;
            let conn=libc::accept4(fd,(&mut peer as *mut libc::sockaddr_vm).cast(),&mut len,libc::SOCK_CLOEXEC);if conn<0{continue}
            let mut out=File::from_raw_fd(conn);
            if peer.svm_cid!=2 {let _=out.write_all(b"host-only\n");continue}
            // One command per connection avoids keeping caller environment in persistent state.
            // Each request is bounded. A separate child owns its request, then exits.
            let pid=libc::fork();if pid<0{continue}if pid>0 {drop(out);continue}
            libc::close(fd);
            libc::signal(libc::SIGCHLD,libc::SIG_DFL);
            let mut input=BufReader::new(out.try_clone().unwrap());
            let mut line=String::new();input.by_ref().take(65537).read_line(&mut line).unwrap();
            if line.len()>65536 {let _=out.write_all(b"{\"error\":\"too-large\"}\n");libc::_exit(2)}
            let req:Value=match serde_json::from_str(&line){Ok(v)=>v,Err(_)=>{let _=out.write_all(b"{\"error\":\"invalid-json\"}\n");libc::_exit(2)}};
            let result=if req["op"]=="writer" {
                let mut child=Command::new("/init").arg("writer").env_clear().stdout(Stdio::piped()).stderr(Stdio::null()).spawn().unwrap();
                let mut ready=String::new();BufReader::new(child.stdout.take().unwrap()).read_line(&mut ready).unwrap();json!({"writer_pid":child.id(),"ready":ready.trim()})
            } else {
                let argv:Vec<String>=match serde_json::from_value(req["argv"].clone()) {Ok(v)=>v,Err(_)=>{let _=out.write_all(b"{\"error\":\"invalid-request\"}\n");libc::_exit(2)}};
                let env:BTreeMap<String,String>=match serde_json::from_value(req["env"].clone()) {Ok(v)=>v,Err(_)=>{let _=out.write_all(b"{\"error\":\"invalid-request\"}\n");libc::_exit(2)}};
                if argv.is_empty() {let _=out.write_all(b"{\"error\":\"invalid-request\"}\n");libc::_exit(2)}
                let o=match Command::new(&argv[0]).args(&argv[1..]).env_clear().envs(env).current_dir("/work").output() {Ok(v)=>v,Err(_)=>{let _=out.write_all(b"{\"error\":\"exec-failed\"}\n");libc::_exit(2)}};
                json!({"code":o.status.code(),"stdout":String::from_utf8_lossy(&o.stdout),"stderr":String::from_utf8_lossy(&o.stderr)})
            };
            writeln!(out,"{result}").unwrap();libc::_exit(0)
        }
    }
}
