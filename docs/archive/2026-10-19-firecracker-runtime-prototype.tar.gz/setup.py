import hashlib, json, os, pathlib, shutil, subprocess, tarfile, urllib.request, xml.etree.ElementTree as ET

BASE=pathlib.Path('/opt/pinfold-fc-trial')
BASE.mkdir(mode=0o755,exist_ok=True)
def get(url):
    return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'pinfold-disposable-trial'}),timeout=60).read()
def download(url,path):
    data=get(url);path.write_bytes(data)
    return {'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
release=json.loads(get('https://api.github.com/repos/firecracker-microvm/firecracker/releases/tags/v1.17.0'))
assets={a['name']:a['browser_download_url'] for a in release['assets']}
name='firecracker-v1.17.0-x86_64.tgz'
archive=BASE/name
manifest={'firecracker_archive':download(assets[name],archive),'release_assets':list(assets)}
with tarfile.open(archive) as tar:
    for item in tar.getmembers():
        basename=pathlib.PurePosixPath(item.name).name
        if basename in ('firecracker-v1.17.0-x86_64','jailer-v1.17.0-x86_64') and item.isfile():
            dest=BASE/('jailer' if basename.startswith('jailer') else 'firecracker')
            dest.write_bytes(tar.extractfile(item).read());dest.chmod(0o755)
s3='https://s3.amazonaws.com/spec.ccfc.min'
ns={'s':'http://s3.amazonaws.com/doc/2006-03-01/'}
tree=ET.fromstring(get(s3+'?list-type=2&prefix=firecracker-ci/&delimiter=/'))
prefix=sorted(e.text for e in tree.findall('s:CommonPrefixes/s:Prefix',ns))[-1]
tree=ET.fromstring(get(s3+'?list-type=2&prefix='+prefix+'x86_64/vmlinux-'))
keys=[e.text for e in tree.findall('s:Contents/s:Key',ns)]
keys=[k for k in keys if pathlib.PurePosixPath(k).name.startswith('vmlinux-6.1.') and pathlib.PurePosixPath(k).name.rsplit('.',1)[-1].isdigit()]
key=sorted(keys,key=lambda k:tuple(map(int,k.rsplit('vmlinux-',1)[1].split('.'))))[-1]
manifest['kernel']=download(s3+'/'+key,BASE/'vmlinux')
manifest['host_kernel']=os.uname().release
manifest['firecracker_version']=subprocess.check_output([str(BASE/'firecracker'),'--version'],text=True).strip()
manifest['jailer_version']=subprocess.check_output([str(BASE/'jailer'),'--version'],text=True).strip()
(BASE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
