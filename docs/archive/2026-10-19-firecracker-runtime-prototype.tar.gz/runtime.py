"""Disposable fixed-input fixture, not a public privileged launcher."""
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import select
import shutil
import signal
import socket
import subprocess
import sys
import time
import uuid

BASE = Path('/opt/pinfold-fc-trial')
STATE = BASE / 'state'
VOLUME = STATE / 'volume.ext4'
CGROOT = Path('/sys/fs/cgroup')
UID = 60001

def syncdir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)

def record(data):
    p = STATE / 'record.tmp'
    with p.open('w') as f:
        json.dump(data, f); f.flush(); os.fsync(f.fileno())
    p.replace(STATE / 'record.json'); syncdir(STATE)

def current():
    p = STATE / 'record.json'
    return json.loads(p.read_text()) if p.exists() else None

def populated(rec):
    p = CGROOT / rec['cgroup'] / 'cgroup.events'
    return p.exists() and 'populated 1' in p.read_text()

def acquire():
    f = open(STATE / 'volume.lock', 'a+')
    try: fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        f.close(); raise RuntimeError('volume-lock-held')
    rec = current()
    if rec and populated(rec):
        f.close(); raise RuntimeError('volume-vmm-alive')
    return f

def prepare():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    STATE.mkdir(mode=0o700, exist_ok=True)
    root = BASE / 'root'
    root.mkdir(exist_ok=True)
    for name in ['proc', 'sys', 'dev', 'tmp', 'work', 'bin']:
        (root / name).mkdir(exist_ok=True)
    shutil.copy2(BASE / 'guest', root / 'init')
    shutil.copy2('/bin/busybox', root / 'bin/busybox')
    for name in ['sh', 'cat', 'ls', 'sync', 'stat', 'sleep', 'ps']:
        p = root / 'bin' / name
        if not p.exists(): p.symlink_to('busybox')
    with (BASE / 'root.ext4').open('wb') as f: f.truncate(64 * 1024 * 1024)
    subprocess.run(['mkfs.ext4', '-q', '-F', '-d', str(root), str(BASE / 'root.ext4')], check=True)
    if not VOLUME.exists():
        with VOLUME.open('wb') as f: f.truncate(128 * 1024 * 1024)
        subprocess.run(['mkfs.ext4', '-q', '-F', str(VOLUME)], check=True)
    os.chown(VOLUME, UID, UID); VOLUME.chmod(0o600)
    syncdir(STATE)

def launch(mode='normal'):
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    lock = acquire()
    generation = uuid.uuid4().hex
    cgname = 'pinfold-trial-' + generation
    cg = CGROOT / cgname
    cg.mkdir()
    jail = BASE / 'jails/firecracker' / generation / 'root'
    jail.mkdir(parents=True)
    for name, source in [('kernel', BASE / 'vmlinux'), ('root.ext4', BASE / 'root.ext4'), ('work.ext4', VOLUME)]:
        os.link(source, jail / name)
    config = {
        'boot-source': {'kernel_image_path': '/kernel', 'boot_args': 'console=ttyS0 reboot=k panic=1 pci=off root=/dev/vda ro init=/init'},
        'drives': [
            {'drive_id': 'root', 'path_on_host': '/root.ext4', 'is_root_device': True, 'is_read_only': True},
            {'drive_id': 'work', 'path_on_host': '/work.ext4', 'is_root_device': False, 'is_read_only': False, 'cache_type': 'Writeback'}],
        'machine-config': {'vcpu_count': 1, 'mem_size_mib': 192},
        'vsock': {'guest_cid': 3, 'uds_path': '/vsock.sock'}}
    (jail / 'config.json').write_text(json.dumps(config))
    rec = {'generation': generation, 'cgroup': cgname, 'guardian_pid': os.getpid(), 'jail': str(jail), 'volume_inode': VOLUME.stat().st_ino}
    record(rec)
    # Membership precedes fork, so a child cannot survive outside the recorded cgroup.
    (cg / 'cgroup.procs').write_text(str(os.getpid()))
    # The lock serializes state transitions only. No child inherits a lifetime lock.
    lock.close()
    if mode == 'before-spawn':
        print('trial-before-spawn', flush=True)
        signal.pause()
    def contain():
        if mode == 'before-exec':
            os.write(1, b'trial-before-exec\n')
            os.kill(os.getpid(), signal.SIGSTOP)
        lib = ctypes.CDLL(None, use_errno=True)
        if lib.unshare(0x40000000) != 0: raise OSError(ctypes.get_errno(), 'netns')
        if lib.prctl(38, 1, 0, 0, 0) != 0: raise OSError(ctypes.get_errno(), 'nnp')
    command = [str(BASE / 'jailer'), '--id', generation, '--exec-file', str(BASE / 'firecracker'),
               '--uid', str(UID), '--gid', str(UID), '--new-pid-ns',
               '--chroot-base-dir', str(BASE / 'jails'), '--', '--api-sock', '/api.sock', '--config-file', '/config.json']
    child = subprocess.Popen(command, stdin=subprocess.DEVNULL, preexec_fn=contain, close_fds=True)
    lib = ctypes.CDLL(None, use_errno=True)
    for cap in range(41):
        if lib.prctl(24, cap, 0, 0, 0) != 0: raise OSError(ctypes.get_errno(), 'cap-drop')
    os.setgroups([]); os.setresgid(60002, 60002, 60002); os.setresuid(60002, 60002, 60002)
    if lib.prctl(38, 1, 0, 0, 0) != 0: raise OSError(ctypes.get_errno(), 'nnp')
    print('trial-launched ' + generation, flush=True)
    # The guardian deliberately has no automatic VMM kill on death: exercise orphan recovery.
    while True: signal.pause()

def stop(expected_generation=None):
    f = open(STATE / 'volume.lock', 'a+')
    fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    rec = current()
    if rec and expected_generation is not None and rec['generation'] != expected_generation:
        f.close(); raise RuntimeError('stale-generation')
    if rec:
        cg = CGROOT / rec['cgroup']
        if cg.exists():
            event = os.open(cg / 'cgroup.events', os.O_RDONLY)
            try:
                poll = select.poll(); poll.register(event, select.POLLPRI | select.POLLERR)
                if populated(rec): (cg / 'cgroup.kill').write_text('1')
                deadline = time.monotonic() + 15
                while True:
                    os.lseek(event, 0, 0)
                    if b'populated 1' not in os.read(event, 4096): break
                    if time.monotonic() >= deadline: raise RuntimeError('teardown-unconfirmed')
                    poll.poll(1000)
            finally: os.close(event)
            cg.rmdir()
        with VOLUME.open('rb') as disk: os.fsync(disk.fileno())
        (STATE / 'record.json').unlink(); syncdir(STATE)
    f.close()
    return rec

def connection():
    rec = current()
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(20)
    sock.connect(str(Path(rec['jail']) / 'vsock.sock'))
    sock.sendall(b'CONNECT 7000\n')
    response = bytearray()
    while not response.endswith(b'\n'): response.extend(sock.recv(1))
    if not response.startswith(b'OK '): raise RuntimeError('vsock-handshake')
    return sock

def rpc(req):
    with connection() as sock:
        sock.sendall(json.dumps(req).encode() + b'\n')
        with sock.makefile('rb') as f: return json.loads(f.readline(1024 * 1024))

if __name__ == '__main__':
    try:
        if sys.argv[1] == 'prepare': prepare()
        elif sys.argv[1] == 'launch': launch(sys.argv[2] if len(sys.argv)>2 else 'normal')
        elif sys.argv[1] == 'admit':
            f = acquire(); print('volume-available'); f.close()
        elif sys.argv[1] == 'stop': print(json.dumps(stop()))
    except RuntimeError as e:
        print(str(e), flush=True); sys.exit(23)
