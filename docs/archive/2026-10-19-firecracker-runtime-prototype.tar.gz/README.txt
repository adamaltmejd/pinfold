Pinfold-owned Firecracker + jailer disposable trial
2026-10-16. No production repository files or spec were changed.

Result

Real x86_64 Firecracker 1.17.0 guests ran under its stock jailer on a leased
Debian 13 VM with nested KVM. The guest kernel was an upstream CI artifact,
6.1.102, not a proposed production kernel. Exact URLs and hashes are in
evidence/manifest.json. The published Firecracker archive checksum matched.

The final trial completed 42 observations: 40 passed, two did not establish
the desired criterion. complete=true in results.json means the experiment
reached its end, not that every criterion passed or Pinfold's guarantees
have been established.

Measured results

- Guest PID 1 and commands had all real/effective/saved/filesystem UIDs and
  GIDs set to 1000, empty supplementary groups, all five capability sets
  empty, no_new_privs=1 and seccomp enabled. Root writes failed EROFS;
  raw block access failed EACCES; setuid(0), unshare(CLONE_NEWUSER) and
  remount failed EPERM. A normal volume write succeeded. Root image hash
  was unchanged. Completed request children were reaped.
- Host Firecracker ran as UID/GID 60001 with empty supplementary groups,
  no effective/permitted/inheritable/ambient capabilities, no_new_privs=1
  and its default seccomp enabled. Mount, PID and network namespaces were
  separate. The jailed root's device/inode matched the prepared directory.
  The guardian dropped to UID/GID 60002 with all capability sets empty.
- The unprivileged caller received a preconnected channel descriptor and
  sent a random synthetic secret over vsock. Only the designated guest
  process environment received it. The process returned its digest, not
  the value. Its argv digest matched the expected secret-free argv.
  Malformed requests and failed exec paths returned fixed error messages.
  The next command did not inherit the previous secret environment.
- No synthetic-secret matches were found in surviving regular files under
  the trial directory, including logs and raw ext4 images, or the sampled
  host argv. A separate public canary spanning a scanner chunk boundary
  validated detection. Host and guest swap were disabled; core limits were
  zero. This is bounded evidence, not exhaustive tracing of all writes or
  transient argv, deleted files, or unrelated host logs.
- An owner crash before spawn left reclaimable state. A child stopped
  before exec remained covered by its generation cgroup after guardian
  death, so another attachment was refused. A running VM kept writing
  after both caller and guardian SIGKILL, while attachment remained denied.
  Stale-generation cleanup was refused without stopping the live VM.
- Recovery killed the recorded cgroup, observed populated=0, fsynced the
  backing file, and cleared the record. The same ext4 inode reopened in a
  new VM; its marker and counter survived (counter observed before crash 2,
  after recovery 21). New writes succeeded. This tests VMM/process death
  with the host still running, not host power loss or hardware durability.

Two unresolved criteria

1. Stock jailer leaves the VMM capability bounding set nonempty:
   CapBnd=000001ffffffffff. The active sets are empty and no_new_privs is
   set, but an exact requirement for an empty host VMM bounding set is not
   met. Do not silently relabel that requirement. Resolve the intended
   scope of the guarantee or prove a suitable extra bootstrap mechanism.
2. Guest-local vsock connection to the control listener timed out rather
   than producing the explicit host-only rejection. The CID-2 check exists
   in source, but this trial did not exercise its reject branch. A timeout
   is not accepted as a security pass. Host-to-guest execution did succeed.

Components and ownership

src/main.rs: static Rust guest init and probe commands. It performs trusted
mount setup, permanently drops privilege, then handles bounded single-request
vsock connections. It uses a small namespace-denial seccomp filter, not the
production Pinfold syscall policy. No PTY or streaming implementation.

runtime.py: disposable Python host fixture with fixed paths, one volume,
and fixed UIDs. Root setup creates the jail, private network namespace and
generation cgroup; the maintained jailer provides chroot/PID namespace and
VMM identity changes. This is not a hardened multiuser privileged API.

Volume ownership uses a root-protected durable generation record and a
nondelegated cgroup. A short flock serializes record changes. The launcher
joins the cgroup before forking, so every possible VMM child inherits its
membership. No lifetime lock is inherited by the child. A populated cgroup
refuses reuse even when the original owner is dead. Cleanup holds the
transition lock, checks generation, kills the group, and waits for empty.

The data disk is a private 128 MiB ext4 file, never host-mounted after guest
use. Firecracker cache_type=Writeback explicitly enables guest flushes;
the default Unsafe mode would not advertise that capability. Root disk is
read-only. There is one vCPU, 192 MiB guest RAM, and no network device.

owner.py: unprivileged caller fixture. A synthetic secret is supplied on an
anonymous pipe and forwarded over a preconnected descriptor. Root launch
configuration contains no secret. Descriptor authorization/brokering for a
real Rust SDK has not been implemented.

trial.py: real-runtime observations, fault injection and cleanup. These are
prototype probes outside the production test suite, not new guarantee rows.

Findings during development

- Kernel had already mounted devtmpfs; init had to remount it with nosuid.
- Source review caught missing x32 syscall rejection and child reaping;
  both were corrected before the final run.
- Child inheritance of lifetime flock blocked cleanup at a pre-exec crash
  barrier. The final design uses cgroup membership and a short transition
  lock instead. Membership before fork also removes the dangerous interval
  in which a surviving child might not yet be represented by the cgroup.
- /proc/PID/root prints '/' in jailer's mount namespace; the observer now
  compares device/inode identity rather than a textual path.
- The descriptor-receiving Python client needed to set its socket timeout
  explicitly. That fixture was corrected before the final secret trial.

Limits before production

No ARM or Apple experiment; no malicious guest-kernel escape test; no
cross-box UID allocation or arbitrary-path admission; no full guest process
inventory proof; no production egress proxy; no CPU/RAM/disk accounting
tests; no host reboot/power-loss test; no ephemeral-deletion test; no OCI
image composition or authenticated privileged broker; no Rust host SDK.
Command output capture is unbounded, and the guest kernel is a dated test
artifact. These files must not be installed as a production runtime.

The result supports continuing with a small Rust host runtime plus trusted
Rust guest init, using jailer and cgroup v2. Volume admission and recovery
must stay inside Pinfold's authority boundary, shared by CLI and SDK. Pi,
Pi Durable and Switchyard can own repository workflows above that boundary.

Reproduction notes

The local Rust guest was built with cargo zigbuild --release --target
x86_64-unknown-linux-musl, using Cargo.lock in this directory. Guest build
dependencies are libc, serde_json and sha2 (the last is for the probe).
setup.py records how upstream artifacts were discovered for this run; use
the exact evidence/manifest.json URLs/hashes to reproduce these versions,
not a newly discovered CI kernel. Remote packages: python3, busybox-static,
e2fsprogs, curl, ca-certificates. runtime.py prepare constructs the images;
trial.py runs the observations on a disposable root-capable KVM host.
Do not run these fixed-root-path fixtures on a normal workstation.

Evidence includes final results, boot logs, and selected earlier failures.
Before lease release, independent inspection found no trial cgroups, no
Firecracker/jailer processes, and no volume ownership record. VM lease
release is recorded separately in cleanup.json.

Primary upstream references

https://github.com/firecracker-microvm/firecracker/blob/v1.17.0/src/jailer/src/env.rs
https://github.com/firecracker-microvm/firecracker/blob/v1.17.0/docs/api_requests/block-caching.md
https://github.com/firecracker-microvm/firecracker/blob/v1.17.0/docs/getting-started.md
